object frmSales: TfrmSales
  Left = 0
  Top = 0
  Caption = 'Sales Screen'
  ClientHeight = 448
  ClientWidth = 453
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Shape1: TShape
    Left = 72
    Top = 32
    Width = 297
    Height = 361
    Brush.Style = bsCross
  end
  object Shape12: TShape
    Left = 24
    Top = 56
    Width = 393
    Height = 49
    Brush.Color = clCream
  end
  object Label7: TLabel
    Left = 185
    Top = 70
    Width = 71
    Height = 27
    Caption = 'SALES'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -24
    Font.Name = 'Times New Roman'
    Font.Style = []
    ParentFont = False
  end
  object btnDisplay: TButton
    Left = 104
    Top = 343
    Width = 241
    Height = 25
    Caption = 'DISPLAY'
    TabOrder = 0
    OnClick = btnDisplayClick
  end
  object btnBack: TButton
    Left = 394
    Top = 8
    Width = 51
    Height = 25
    Caption = 'BACK'
    DoubleBuffered = False
    ParentDoubleBuffered = False
    TabOrder = 1
    OnClick = btnBackClick
  end
  object redout: TRichEdit
    Left = 104
    Top = 111
    Width = 241
    Height = 226
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    Lines.Strings = (
      '')
    ParentFont = False
    TabOrder = 2
  end
end
