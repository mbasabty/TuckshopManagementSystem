unit frmStock_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, pngimage, frmNewStock_u, frmReturns_u, frmSoldStock_u;

type
  TfrmStock = class(TForm)
    Shape1: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape2: TShape;
    Shape12: TShape;
    Shape13: TShape;
    Shape14: TShape;
    Shape16: TShape;
    Shape17: TShape;
    Shape18: TShape;
    Shape20: TShape;
    Shape15: TShape;
    Shape11: TShape;
    Shape5: TShape;
    Label1: TLabel;
    btnBack: TButton;
    btnStock: TButton;
    btnPurchasedStock: TButton;
    btnReturnedStock: TButton;
    Image1: TImage;
    Image3: TImage;
    Shape3: TShape;
    Shape4: TShape;
    Shape6: TShape;
    Image2: TImage;
    procedure btnPurchasedStockClick(Sender: TObject);
    procedure btnReturnedStockClick(Sender: TObject);
    procedure btnStockClick(Sender: TObject);
    procedure btnBackClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmStock: TfrmStock;

implementation
uses
  frmMainMenu_u;

{$R *.dfm}

procedure TfrmStock.btnStockClick(Sender: TObject);
//link with stock sold screen
begin
  frmStock.Hide;
  frmSoldStock.show;
end;

procedure TfrmStock.btnBackClick(Sender: TObject);
//link with MainMenu
begin
  frmStock.Hide;
  frmMainMenu.show;
end;

procedure TfrmStock.btnPurchasedStockClick(Sender: TObject);
//link with New Stock Screen
begin
  frmStock.Hide;
  frmNewStock.show;
end;

procedure TfrmStock.btnReturnedStockClick(Sender: TObject);
//link with Returns Screen
begin
  frmStock.hide;
  frmReturns.show;
end;

end.
