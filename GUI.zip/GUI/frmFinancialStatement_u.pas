unit frmFinancialStatement_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls, dmTTControl_u, Grids, DBGrids;

type
  TfrmFinancialStatement = class(TForm)
    Shape1: TShape;
    Shape12: TShape;
    Label7: TLabel;
    btnDisplay: TButton;
    btnBack: TButton;
    redout: TRichEdit;

    procedure btnBackClick(Sender: TObject);
    procedure btnDisplayClick(Sender: TObject);
    procedure btnDisplayMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmFinancialStatement: TfrmFinancialStatement;

implementation
uses
  frmFinances_u;

{$R *.dfm}



procedure TfrmFinancialStatement.btnBackClick(Sender: TObject);
//link with finances screen
begin
  frmFinancialStatement.hide;
  frmFinances.show;
end;

procedure TfrmFinancialStatement.btnDisplayClick(Sender: TObject);
var
  myfile : textfile;
  iPos, iInvoiceNo  : integer;
  sProduct, sManu, sPrice, sQuantity , sLine: String;

begin
/// tab spacing
  redout.Paragraph.TabCount := 4;
  redout.paragraph.tab[0] := 100;
  redout.paragraph.tab[1] := 200;
  redout.paragraph.tab[2] := 300;
  redout.paragraph.tab[3] := 400;
  redout.paragraph.tab[4] := 500;
  redout.Lines.Add('Queens College Boys High School Tuck Shops Pre-Adjusated Bank Statement');
  redout.Lines.Add(DateToStr(Date));
  redout.Lines.Add('-------------------------------------------------------------------------------------------------------------------------------------------------------------------');
  redout.Lines.Add('Invoice No'+#9+'Product'+#9+'Manu'+#9+'Quantity'+#9+'Price');
  redout.Lines.Add('-------------------------------------------------------------------------------------------------------------------------------------------------------------------');
/// extracting from a textfile

/// checking if file exists
if (fileexists ('TotalPurchases.txt')<> true) then
  begin
    showmessage('File does not exist');
    Exit;
  end;

///  reading from a textfile
 AssignFile(myfile,'TotalPurchases.txt');
 Reset(myfile);
/// reading begins
 while NOT eof (myfile) do
  begin
    Readln(myfile,sLine);
    iPos := pos('#',sline);
    iInvoiceNo := strtoint(copy(sLine,1,iPos-1));
    delete(sLine,1,iPos);
    iPos := pos('#',sline);
    sProduct := copy(sLine,1,iPos-1);
    delete(sLine,1, iPos);
    iPos := pos('#',sline);
    sManu := copy(sLine, 1, iPos-1);
    delete(sLine,1 , iPos);
    iPos := pos('#',sline);
    sPrice := copy(sLine,1,iPos-1);
    delete(sLine,1,iPos);
    iPos := pos('#',sline);
    sQuantity := copy(sLine,1,iPos-1);
    ///displaying on the richedit
    redout.Lines.Add('000'+inttostr(iInvoiceNo)+#9+sProduct+#9+sManu+#9+sPrice+#9+sQuantity);
  end;
  CloseFile(myfile);
   redout.Lines.Add('-------------------------------------------------------------------------------------------------------------------------------------------------------------------');
  //calculating the total

end;

procedure TfrmFinancialStatement.btnDisplayMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  redout.Clear;
end;

end.
