program frmMainPage_p;

uses
  Forms,
  frmMainPage_u in 'frmMainPage_u.pas' {frmMainPage},
  frmMenu_u in 'frmMenu_u.pas' {frmMenu};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmMainPage, frmMainPage);
  Application.CreateForm(TfrmMenu, frmMenu);
  Application.Run;
end.
