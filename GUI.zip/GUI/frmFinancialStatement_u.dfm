object frmFinancialStatement: TfrmFinancialStatement
  Left = 0
  Top = 0
  Caption = 'FINANCIAL STATEMENT SCREEN'
  ClientHeight = 625
  ClientWidth = 878
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Shape1: TShape
    Left = 56
    Top = 16
    Width = 721
    Height = 553
    Brush.Style = bsCross
  end
  object Shape12: TShape
    Left = 8
    Top = 32
    Width = 393
    Height = 49
    Brush.Color = clCream
  end
  object Label7: TLabel
    Left = 72
    Top = 46
    Width = 267
    Height = 27
    Caption = 'FINANCIAL STATEMENT'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -24
    Font.Name = 'Times New Roman'
    Font.Style = []
    ParentFont = False
  end
  object btnDisplay: TButton
    Left = 72
    Top = 535
    Width = 685
    Height = 25
    Caption = 'DISPLAY'
    TabOrder = 0
    OnClick = btnDisplayClick
    OnMouseDown = btnDisplayMouseDown
  end
  object btnBack: TButton
    Left = 706
    Top = 32
    Width = 51
    Height = 25
    Caption = 'BACK'
    DoubleBuffered = False
    ParentDoubleBuffered = False
    TabOrder = 1
    OnClick = btnBackClick
  end
  object redout: TRichEdit
    Left = 72
    Top = 87
    Width = 685
    Height = 442
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    Lines.Strings = (
      '')
    ParentFont = False
    TabOrder = 2
  end
end
