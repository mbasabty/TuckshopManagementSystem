unit frmNewStock_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, ComCtrls, Spin, dmTTControl_u;

type
  TfrmNewStock = class(TForm)
    Shape1: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    btnBack: TButton;
    Shape7: TShape;
    Shape5: TShape;
    Shape6: TShape;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    edtPrice: TEdit;
    edtSupplierID: TEdit;
    spnQuanitiy: TSpinEdit;
    dtpExpiryDate: TDateTimePicker;
    Shape2: TShape;
    Shape11: TShape;
    btnRecord: TButton;
    Shape12: TShape;
    Label7: TLabel;
    Shape4: TShape;
    edtProductName: TEdit;
    chkDiscount: TCheckBox;
    edtManu: TEdit;
    Label2: TLabel;
    Label1: TLabel;
    Shape3: TShape;
    rgpPurchases: TRadioGroup;
    procedure btnBackClick(Sender: TObject);
    procedure btnRecordClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmNewStock: TfrmNewStock;

implementation
uses
  frmStock_u;

{$R *.dfm}

procedure TfrmNewStock.btnBackClick(Sender: TObject);
begin
  frmNewStock.Hide;
  frmStock.show;
end;

procedure TfrmNewStock.btnRecordClick(Sender: TObject);
begin
  with dmTTControl do
  begin
    tblStockPurchased.Open;
    tblStockPurchased.sort := 'ProductID';  //primary key
    tblStockPurchased.last;

  ///enter a record to a database
    tblStockPurchased.Insert;
    tblStockPurchased['ProductName']   := edtProductName.Text;
    tblStockPurchased['Manufacturer']  := edtManu.text;
    tblStockPurchased['SupplierID']    := edtSupplierID.Text;
    tblStockPurchased['Quantity']      := spnQuanitiy.Value;
    tblStockPurchased['Price']         := strtofloat(edtPrice.Text);
    tblStockPurchased['ExpiryDate']    := dtpExpiryDate.date;

    case rgpPurchases.itemindex of
    0 : tblStockPurchased['Credit Purchase'] := true;
    1 : tblStockPurchased['Credit Purchase'] := false;
    end;

    showmessage('Record has been successfully saved');
    tblStockPurchased.Post;
  end;
end;

end.
