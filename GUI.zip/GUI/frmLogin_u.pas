unit frmLogin_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, pngimage, ExtCtrls, frmMainMenu_u, dmTTControl_u;

type
  TfrmLogin = class(TForm)
    Shape3: TShape;
    Shape4: TShape;
    Shape5: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Shape11: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape2: TShape;
    Shape12: TShape;
    Shape13: TShape;
    Shape14: TShape;
    Label1: TLabel;
    Label2: TLabel;
    edtUsername: TEdit;
    edtPassword: TEdit;
    btnLogin: TButton;
    btnBack: TButton;
    image: TImage;
    lblSignUp: TLabel;
    Shape1: TShape;
    Shape6: TShape;
    btnHelp: TButton;
    Shape15: TShape;
    Image1: TImage;
    Image3: TImage;
    Image2: TImage;
    procedure btnLoginClick(Sender: TObject);
    procedure btnBackClick(Sender: TObject);
    procedure imageMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure imageMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure Image4MouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure lblSignUpMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure btnHelpClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmLogin: TfrmLogin;

implementation
uses
  frmMenu_u, frmSignUp_u, frmHelp_u;


{$R *.dfm}

procedure TfrmLogin.btnBackClick(Sender: TObject);
begin
  frmLogin.Hide;
  frmMenu.show;
end;

procedure TfrmLogin.btnHelpClick(Sender: TObject);
begin
  frmHelp.show;
  frmLogin.Hide;
end;

procedure TfrmLogin.btnLoginClick(Sender: TObject);
var
  login : textfile;
  sPassword, sAdmin, sLine, sPass, sAdminNo, sUsername :string;
  iComma : integer;
  bMatch : boolean;

begin
//reading from a database
  sPassword := edtPassword.text;
  sUsername := edtUsername.text;
  bMatch := false;
/////  ////
  with dmTTControl do
    begin
      tblUsers.Open;
      tblUsers.Sort:= 'AdminNo';
      tblUsers.First;
//// MAGIC LOOP ////
      while NOT (tblUsers.Eof) do
      begin
        if((tblUsers['Password']=sPassword) AND (tblUsers['Username']= sUsername)) then
        bMatch := true;
        tblUsers.Next;
      end;
    end;
//// IF TRUE ////
        if bMatch = true then
      begin
        frmLogin.Hide;
        frmMainMenu.Show
      end
     else
        showmessage('Incorrect admin number or password');
end;

procedure TfrmLogin.Image4MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  frmLogin.Hide;
  frmSignUp.Show;
end;

procedure TfrmLogin.imageMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  edtPassword.passwordchar := #0;
  Image.Picture.LoadFromFile('hidepassword.png');
end;

procedure TfrmLogin.imageMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  edtPassword.passwordchar := '*';
  Image.Picture.LoadFromFile('showpassword.png');
end;

procedure TfrmLogin.lblSignUpMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  frmLogin.Hide;
  frmSignUp.Show;
end;

end.
