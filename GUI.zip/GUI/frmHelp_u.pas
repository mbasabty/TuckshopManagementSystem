unit frmHelp_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls, pngimage;

type
  TfrmHelp = class(TForm)
    Shape1: TShape;
    Label1: TLabel;
    RichEdit1: TRichEdit;
    Image1: TImage;
    Shape2: TShape;
    Image2: TImage;
    btnSignUp: TButton;
    procedure btnSignUpClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmHelp: TfrmHelp;

implementation
uses
  frmSignUp_u;

{$R *.dfm}

procedure TfrmHelp.btnSignUpClick(Sender: TObject);
begin
  frmSignUp.show;
  frmHelp.Hide;
end;

end.
