program frmSignUp_p;

uses
  Forms,
  frmMainPage_u in 'frmMainPage_u.pas' {frmMainPage},
  frmMenu_u in 'frmMenu_u.pas' {frmMenu},
  frmLogin_u in 'frmLogin_u.pas' {frmLogin},
  frmMainMenu_u in 'frmMainMenu_u.pas' {frmMainMenu},
  frmStock_u in 'frmStock_u.pas' {frmStock},
  frmUsers_u in 'frmUsers_u.pas' {frmUsers},
  frmFinances_u in 'frmFinances_u.pas' {frmFinances},
  frmNewStock_u in 'frmNewStock_u.pas' {frmNewStock},
  frmReturns_u in 'frmReturns_u.pas' {frmReturns},
  frmSoldStock_u in 'frmSoldStock_u.pas' {frmSoldStock},
  frmSales_u in 'frmSales_u.pas' {frmSales},
  frmFinancialStatement_u in 'frmFinancialStatement_u.pas' {frmFinancialStatement},
  frmSignUp_u in 'frmSignUp_u.pas' {Form1},
  frmHelp_u in 'frmHelp_u.pas' {frmHelp};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmMainPage, frmMainPage);
  Application.CreateForm(TfrmMenu, frmMenu);
  Application.CreateForm(TfrmLogin, frmLogin);
  Application.CreateForm(TfrmMainMenu, frmMainMenu);
  Application.CreateForm(TfrmStock, frmStock);
  Application.CreateForm(TfrmUsers, frmUsers);
  Application.CreateForm(TfrmFinances, frmFinances);
  Application.CreateForm(TfrmNewStock, frmNewStock);
  Application.CreateForm(TfrmReturns, frmReturns);
  Application.CreateForm(TfrmSoldStock, frmSoldStock);
  Application.CreateForm(TfrmSales, frmSales);
  Application.CreateForm(TfrmFinancialStatement, frmFinancialStatement);
  Application.CreateForm(TfrmSignUp, frmSignUp);
  Application.CreateForm(TfrmHelp, frmHelp);
  Application.Run;
end.
