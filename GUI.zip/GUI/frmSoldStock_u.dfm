object frmSoldStock: TfrmSoldStock
  Left = 0
  Top = 0
  Caption = 'SOLD STOCK SCREEN'
  ClientHeight = 620
  ClientWidth = 984
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Shape1: TShape
    Left = 35
    Top = 8
    Width = 921
    Height = 599
    Brush.Style = bsCross
  end
  object Shape8: TShape
    Left = 763
    Top = 500
    Width = 145
    Height = 115
    Shape = stCircle
  end
  object Shape10: TShape
    Left = 735
    Top = 532
    Width = 116
    Height = 83
    Brush.Color = clInactiveCaption
    Shape = stCircle
  end
  object Shape12: TShape
    Left = 0
    Top = 11
    Width = 393
    Height = 49
    Brush.Color = clCream
  end
  object Label7: TLabel
    Left = 48
    Top = 23
    Width = 222
    Height = 27
    Caption = 'PURCHASED STOCK'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -24
    Font.Name = 'Times New Roman'
    Font.Style = []
    ParentFont = False
  end
  object Shape9: TShape
    Left = 851
    Top = 500
    Width = 97
    Height = 115
    Brush.Color = clCream
    Shape = stCircle
  end
  object Shape7: TShape
    Left = 875
    Top = 439
    Width = 193
    Height = 168
    Brush.Color = clGradientInactiveCaption
    Shape = stCircle
  end
  object lblTotalPurchases: TLabel
    Left = 240
    Top = 493
    Width = 62
    Height = 19
    Caption = 'R 00.00'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Shape2: TShape
    Left = 227
    Top = 492
    Width = 166
    Height = 28
    Brush.Style = bsClear
  end
  object Shape3: TShape
    Left = 399
    Top = 420
    Width = 9
    Height = 169
  end
  object btnBack: TButton
    Left = 897
    Top = 11
    Width = 51
    Height = 25
    Caption = 'BACK'
    TabOrder = 0
    OnClick = btnBackClick
  end
  object btnReset: TButton
    Left = 75
    Top = 564
    Width = 146
    Height = 25
    Caption = 'RESET DATABASE'
    Font.Charset = HEBREW_CHARSET
    Font.Color = clRed
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsUnderline]
    ParentFont = False
    TabOrder = 1
    OnClick = btnResetClick
  end
  object DBGrid1: TDBGrid
    Left = 48
    Top = 72
    Width = 897
    Height = 337
    DataSource = dmTTControl.dsrStockPurchased
    TabOrder = 2
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
  end
  object Button1: TButton
    Left = 75
    Top = 415
    Width = 146
    Height = 32
    Caption = 'SEARCH FOR A RECORD'
    TabOrder = 3
    OnClick = btnSearchClick
  end
  object btnTotal: TButton
    Left = 75
    Top = 491
    Width = 146
    Height = 31
    Caption = 'TOTAL PURCHASES'
    TabOrder = 4
    OnClick = btnTotalClick
  end
  object btnDelete: TButton
    Left = 75
    Top = 453
    Width = 146
    Height = 32
    Caption = 'DELETE'
    TabOrder = 5
    OnClick = btnDeleteClick
  end
  object btnCreditPurchases: TButton
    Left = 606
    Top = 417
    Width = 195
    Height = 32
    Caption = 'TOTAL CREDIT PURHCASES'
    TabOrder = 6
    OnClick = btnCreditPurchasesClick
    OnMouseDown = btnCreditPurchasesMouseDown
  end
  object btnCashPurchases: TButton
    Left = 414
    Top = 417
    Width = 186
    Height = 32
    Caption = 'TOTAL OF CASH PURHCASES'
    TabOrder = 7
    OnClick = btnCashPurchasesClick
    OnMouseDown = btnCashPurchasesMouseDown
  end
  object redout: TRichEdit
    Left = 414
    Top = 455
    Width = 334
    Height = 89
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = []
    ParentFont = False
    TabOrder = 8
  end
  object Button3: TButton
    Left = 75
    Top = 526
    Width = 146
    Height = 32
    Caption = 'EXPIRY DATE CHECK'
    TabOrder = 9
  end
  object btnSavePurchases: TButton
    Left = 414
    Top = 550
    Width = 334
    Height = 25
    Caption = 'SAVE RETURNS AND STOCK PURCHASES'
    TabOrder = 10
    OnClick = btnSavePurchasesClick
  end
  object btnTextfile: TButton
    Left = 227
    Top = 564
    Width = 166
    Height = 25
    Caption = 'EXTRACTING TO TEXT FILE'
    TabOrder = 11
    OnClick = btnTextfileClick
  end
  object btnGrandTotal: TButton
    Left = 227
    Top = 526
    Width = 166
    Height = 32
    Caption = 'SAVE TOTAL'
    TabOrder = 12
    OnClick = btnGrandTotalClick
  end
end
