unit frmSoldStock_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls, Grids, DBGrids, dmTTControl_u;

type
  TfrmSoldStock = class(TForm)
    Shape1: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    btnBack: TButton;
    Shape7: TShape;
    Shape12: TShape;
    Label7: TLabel;
    DBGrid1: TDBGrid;
    btnReset: TButton;
    Button1: TButton;
    lblTotalPurchases: TLabel;
    btnTotal: TButton;
    btnDelete: TButton;
    btnCreditPurchases: TButton;
    btnCashPurchases: TButton;
    Shape2: TShape;
    Shape3: TShape;
    redout: TRichEdit;
    Button3: TButton;
    btnSavePurchases: TButton;
    btnTextfile: TButton;
    btnGrandTotal: TButton;
    procedure btnBackClick(Sender: TObject);
    procedure btnResetClick(Sender: TObject);
    procedure btnSortClick(Sender: TObject);
    procedure btnSortDecsClick(Sender: TObject);
    procedure btnPriceClick(Sender: TObject);
    procedure btnSearchClick(Sender: TObject);
    procedure btnTotalClick(Sender: TObject);
    procedure btnDeleteClick(Sender: TObject);
    procedure btnCashPurchasesClick(Sender: TObject);
    procedure btnCreditPurchasesClick(Sender: TObject);
    procedure btnCreditPurchasesMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure btnCashPurchasesMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure btnSavePurchasesClick(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure btnTextfileClick(Sender: TObject);
    procedure btnGrandTotalClick(Sender: TObject);



  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmSoldStock: TfrmSoldStock;

implementation
uses
  frmStock_u;
var
  rTotal : real;
  arrPrice : array[1..50] of real;

{$R *.dfm}

procedure TfrmSoldStock.btnBackClick(Sender: TObject);
//link with stock screen
begin
  frmSoldStock.Hide;
  frmStock.show;
end;
procedure TfrmSoldStock.btnResetClick(Sender: TObject);
//Reseting a database
begin
  with dmTTControl do
  begin
    tblStockPurchased.filtered := false;
  end;
end;

//deleting
procedure TfrmSoldStock.btnCashPurchasesClick(Sender: TObject);
 var
  rCashTotal : real;
begin
  redout.Lines.Add('PURCHASES : CASH AND CREDIT');
  redout.Lines.Add('---------------------------------------------------------------------------------');
  redout.lines.Add('');
  ///calcualting the cash purchases

 rCashTotal := 0;
 dmTTControl.tblStockPurchased.First;
 with dmTTControl do
 begin
   while NOT(tblStockPurchased.Eof) do
    begin
      IF(tblStockPurchased['Credit Purchase']= false) then
      begin
        rCashTotal := rCashTotal + tblStockPurchased['Price'];
      end;
      tblStockPurchased.Next;
    end;
 end;
 redout.Lines.Add('Credit purchases : '+ floattostrF(rCashTotal,ffCurrency,8,2));
end;


procedure TfrmSoldStock.btnCashPurchasesMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  redout.Lines.Clear;
end;

procedure TfrmSoldStock.btnCreditPurchasesClick(Sender: TObject);
var
  rCreditTotal : real;
begin
  redout.Lines.Add('PURCHASES : CASH AND CREDIT');
  redout.Lines.Add('---------------------------------------------------------------------------------');
  redout.lines.Add('');

  ///calcualting the cash purschases

 rCreditTotal := 0;
 dmTTControl.tblStockPurchased.First;
 with dmTTControl do
 begin
   while NOT(tblStockPurchased.Eof) do
    begin
      IF(tblStockPurchased['Credit Purchase']= true) then
      begin
        rCreditTotal := rCreditTotal + tblStockPurchased['Price'];
      end;
      tblStockPurchased.Next;
    end;
 end;
 redout.Lines.Add('Credit purchases : '+ floattostrF(rCreditTotal,ffCurrency,8,2));
end;

procedure TfrmSoldStock.btnCreditPurchasesMouseDown(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  redout.Lines.clear
end;

procedure TfrmSoldStock.btnDeleteClick(Sender: TObject);
begin
 with dmTTControl do
 begin
   if (MessageDLG('Are you sure you want to delete record for : '+
   tblStockPurchased['Manufacturer'] + ' ' + tblStockPurchased['SupplierID'] + '?', mtWarning, [mbOk,mbCancel],0) = mrOk)  then
   tblStockPurchased.Delete;
 end;
end;

procedure TfrmSoldStock.btnGrandTotalClick(Sender: TObject);
var
  i : integer;
  myfile : textfile;
  sLine : string;
begin
  /// checking if file exists
  i := 1;
  if(fileexists('StockSold.txt')<>true) then
    begin
       showmessage('File does not exist');
       EXIT;
    end;

  //reading from a textfile
  AssignFile(myfile,'StockSold.txt');
  Reset(myfile);
  while NOT eof(myfile) do
    begin
      readln(myfile,sLine);
      delete(sLine,1,pos('#',sLine));
      delete(sLine,1,pos('#',sLine));
      arrPrice[i] := strtofloat(sLine);
    end;
    Showmessage('It has been saved');

end;

procedure TfrmSoldStock.btnPriceClick(Sender: TObject);
begin
/// filterinSg through rices///

  with dmTTControl do
  begin
    tblStockPurchased.filtered := false;
    tblStockPurchased.Filter := 'price = ''45''';
    tblStockPurchased.Filtered := true;
  end;
end;

procedure TfrmSoldStock.btnSavePurchasesClick(Sender: TObject);
var
  rTotal, rTotal2 :real;
  myfile : textfile;
begin
//////
  rTotal := 0;
  rTotal2 := 0;
  dmTTControl.tblStockReturned.First;
  with dmTTControl do
   begin
     while NOT(tblStockReturned.Eof) do
      begin
        rTotal := rTotal + tblStockReturned['Price'];
        tblStockReturned.Next;
      end;
   end;

   dmTTControl.tblStockPurchased.First;
  with dmTTControl do
   begin
     while NOT(tblStockPurchased.Eof) do
      begin
        rTotal2 := rTotal2 + tblStockPurchased['Price'];
        tblStockPurchased.Next;
      end;
   end;

   AssignFile(myfile,'SAVE.txt');
   Rewrite(Myfile);
   Writeln(Myfile,floattostr(rTotal)+'#'+floattostr(rTotal2));
   showmessage('It has been saved successfully');
   closefile(myfile);


  { dmTTControl.tblFinances.Insert;
   dmTTControl.tblFinances.Edit;
   dmTTControl.tblFinances['RETURNS']:= rTotal;
   showmessage('Total has be saved'); }
end;

procedure TfrmSoldStock.btnSearchClick(Sender: TObject);
//searching for a record
var
  sSupplier : string;
begin
  with dmTTControl do
  begin
    sSupplier := inputbox('supplier','enter supplier',' ');
    tblStockPurchased.filtered := false;
    tblStockPurchased.filter := 'SupplierID =' + quotedstr(sSupplier);
    tblStockPurchased.filtered := true;
  end;
end;

procedure TfrmSoldStock.btnSortClick(Sender: TObject);
begin
  /// sorting ascending order
  with dmTTControl do
  begin
    tblStockPurchased.filtered := false;
    tblStockPurchased.Sort := 'Quantity';
    tblStockPurchased.Filtered := true;
  end;
end;

procedure TfrmSoldStock.btnSortDecsClick(Sender: TObject);
begin
   /// sorting descending order
  with dmTTControl do
  begin
    tblStockPurchased.filtered := false;
    tblStockPurchased.Sort := 'Quantity DESC';
    tblStockPurchased.Filtered := true;
  end;
end;


procedure TfrmSoldStock.btnTextfileClick(Sender: TObject);
var
  myfile : textfile;

begin
//creating a textfile
  with dmTTControl do
    begin
      tblStockPurchased.Open;
      tblStockPurchased.Sort := 'ProductID';
      tblStockPurchased.First;
        while NOT (tblStockPurchased.Eof) do
          begin
              AssignFile(myfile,'StockSold.txt');
              Append(myfile);
              Writeln(myfile,tblStockPurchased['ProductName'],'#',tblStockPurchased['Quantity'],'#',tblStockPurchased['Price']);
              closefile(myfile);
              tblStockPurchased.Next;
          end;
    end;
   showmessage('All product names, quantity and price has been saved');
end;

procedure TfrmSoldStock.btnTotalClick(Sender: TObject);
var
  rTotal : real;
begin
 rTotal := 0;
 dmTTControl.tblStockPurchased.First;
 with dmTTControl do
 begin
   while NOT(tblStockPurchased.Eof) do
    begin
      rTotal := rTotal + tblStockPurchased['Price'];
      tblStockPurchased.Next;
    end;
 end;
 lblTotalPurchases.caption := floattostrF(rTotal,ffCurrency,8,2);
end;


procedure TfrmSoldStock.Button4Click(Sender: TObject);
var
  rTotal : real;
begin
//////
  rTotal := 0;
  dmTTControl.tblStockPurchased.First;
  with dmTTControl do
   begin
     while NOT(tblStockPurchased.Eof) do
      begin
        rTotal := rTotal + tblStockPurchased['Price'];
        tblStockPurchased.Next;
      end;
   end;
   dmTTControl.tblFinances.Insert;
// dmTTControl.tblFinances.Edit;
   dmTTControl.tblFinances['SoldStock']:= rTotal;
   showmessage('Total has be saved');
end;
end.
