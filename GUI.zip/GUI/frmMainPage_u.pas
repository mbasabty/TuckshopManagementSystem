unit frmMainPage_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, pngimage, ExtCtrls, frmMenu_u, Menus;

type
  TfrmMainPage = class(TForm)
    Shape1: TShape;
    Shape4: TShape;
    Shape5: TShape;
    Shape6: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Label1: TLabel;
    Shape11: TShape;
    Shape13: TShape;
    Shape14: TShape;
    Shape17: TShape;
    Shape18: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape3: TShape;
    Image1: TImage;
    Image2: TImage;
    Image3: TImage;
    btnProceed: TButton;
    Shape2: TShape;
    procedure btnProceedClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmMainPage: TfrmMainPage;

implementation
uses
 frmSoldStock_u;

{$R *.dfm}

procedure TfrmMainPage.btnProceedClick(Sender: TObject);
//proceed button
begin
  frmMainPage.Hide;
  frmMenu.show;
end;

procedure TfrmMainPage.Button1Click(Sender: TObject);
begin
 frmSoldStock.show;
end;

end.
