object frmNewStock: TfrmNewStock
  Left = 0
  Top = 0
  Caption = 'New Stock'
  ClientHeight = 620
  ClientWidth = 829
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  PrintScale = poPrintToFit
  PixelsPerInch = 96
  TextHeight = 13
  object Shape1: TShape
    Left = 57
    Top = 24
    Width = 690
    Height = 514
    Brush.Style = bsCross
  end
  object Shape8: TShape
    Left = 536
    Top = 477
    Width = 145
    Height = 115
    Shape = stCircle
  end
  object Shape9: TShape
    Left = 497
    Top = 477
    Width = 97
    Height = 115
    Brush.Color = clCream
    Shape = stCircle
  end
  object Shape10: TShape
    Left = 438
    Top = 509
    Width = 116
    Height = 83
    Brush.Color = clInactiveCaption
    Shape = stCircle
  end
  object Shape7: TShape
    Left = 592
    Top = 424
    Width = 193
    Height = 168
    Brush.Color = clGradientInactiveCaption
    Shape = stCircle
  end
  object Shape5: TShape
    Left = 113
    Top = 238
    Width = 217
    Height = 22
  end
  object Shape6: TShape
    Left = 113
    Top = 266
    Width = 217
    Height = 22
  end
  object Label3: TLabel
    Left = 159
    Top = 238
    Width = 68
    Height = 23
    Caption = 'Quantity'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label4: TLabel
    Left = 159
    Top = 266
    Width = 38
    Height = 23
    Caption = 'Price'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Shape2: TShape
    Left = 113
    Top = 294
    Width = 217
    Height = 23
  end
  object Shape11: TShape
    Left = 113
    Top = 324
    Width = 217
    Height = 23
  end
  object Label5: TLabel
    Left = 159
    Top = 295
    Width = 87
    Height = 23
    Caption = 'Expiry Date'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label6: TLabel
    Left = 159
    Top = 324
    Width = 85
    Height = 23
    Caption = 'Supplier ID'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Shape12: TShape
    Left = 8
    Top = 48
    Width = 393
    Height = 49
    Brush.Color = clCream
  end
  object Label7: TLabel
    Left = 84
    Top = 62
    Width = 222
    Height = 27
    Caption = 'PURCHASED STOCK'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -24
    Font.Name = 'Times New Roman'
    Font.Style = []
    ParentFont = False
  end
  object Shape4: TShape
    Left = 113
    Top = 184
    Width = 217
    Height = 21
  end
  object Label2: TLabel
    Left = 159
    Top = 184
    Width = 110
    Height = 23
    Caption = 'Product Name'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Shape3: TShape
    Left = 113
    Top = 213
    Width = 217
    Height = 19
  end
  object Label1: TLabel
    Left = 159
    Top = 211
    Width = 116
    Height = 23
    Caption = 'Manufactuerer'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object btnBack: TButton
    Left = 679
    Top = 32
    Width = 60
    Height = 25
    Caption = 'BACK'
    TabOrder = 0
    OnClick = btnBackClick
  end
  object edtPrice: TEdit
    Left = 345
    Top = 266
    Width = 257
    Height = 21
    TabOrder = 1
    TextHint = 'R1000.00'
  end
  object edtSupplierID: TEdit
    Left = 345
    Top = 324
    Width = 257
    Height = 21
    TabOrder = 2
    TextHint = 'Enter Supplier ID'
  end
  object spnQuanitiy: TSpinEdit
    Left = 345
    Top = 238
    Width = 257
    Height = 22
    MaxValue = 100
    MinValue = 0
    TabOrder = 3
    Value = 0
  end
  object dtpExpiryDate: TDateTimePicker
    Left = 345
    Top = 293
    Width = 257
    Height = 25
    Date = 45105.642920451390000000
    Time = 45105.642920451390000000
    TabOrder = 4
  end
  object btnRecord: TButton
    Left = 117
    Top = 496
    Width = 139
    Height = 25
    Caption = 'RECORD'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 5
    OnClick = btnRecordClick
  end
  object edtProductName: TEdit
    Left = 345
    Top = 184
    Width = 257
    Height = 21
    TabOrder = 6
    TextHint = 'enter product name'
  end
  object chkDiscount: TCheckBox
    Left = 345
    Top = 360
    Width = 169
    Height = 39
    Caption = 'Discount received'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 7
  end
  object edtManu: TEdit
    Left = 345
    Top = 211
    Width = 257
    Height = 21
    TabOrder = 8
    TextHint = 'enter manufacturer'
  end
  object rgpPurchases: TRadioGroup
    Left = 113
    Top = 360
    Width = 185
    Height = 105
    Caption = 'Purchases'
    Items.Strings = (
      'Credit Purchase'
      'Cash Purchase')
    TabOrder = 9
  end
end
