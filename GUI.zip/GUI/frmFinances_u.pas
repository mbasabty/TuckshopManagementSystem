unit frmFinances_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, pngimage, frmSales_u, frmFinancialStatement_u;

type
  TfrmFinances = class(TForm)
    Shape1: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Shape11: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape2: TShape;
    Shape12: TShape;
    Shape13: TShape;
    Shape14: TShape;
    Shape16: TShape;
    Shape17: TShape;
    Shape18: TShape;
    Shape20: TShape;
    Shape15: TShape;
    Shape5: TShape;
    Label1: TLabel;
    btnBack: TButton;
    Shape3: TShape;
    Shape6: TShape;
    Image1: TImage;
    Image2: TImage;
    btnSales: TButton;
    btnFinancialStatements: TButton;
    procedure btnFinancialStatementsClick(Sender: TObject);
    procedure btnSalesClick(Sender: TObject);
    procedure btnBackClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmFinances: TfrmFinances;

implementation
uses
  frmMainMenu_u;

{$R *.dfm}

procedure TfrmFinances.btnSalesClick(Sender: TObject);
//link with sales scree
begin
  frmFinances.Hide;
  frmSales.show;

end;

procedure TfrmFinances.btnBackClick(Sender: TObject);
//link with main menu screen
begin
  frmFinances.hide;
  frmMainMenu.show;
end;

procedure TfrmFinances.btnFinancialStatementsClick(Sender: TObject);
//link with financial statement scree
begin
  frmFinances.Hide;
  frmFinancialStatement.show;
end;

end.
