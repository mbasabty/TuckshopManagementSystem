object frmReturns: TfrmReturns
  Left = 0
  Top = 0
  Caption = 'Returns Screen'
  ClientHeight = 554
  ClientWidth = 842
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  PixelsPerInch = 96
  TextHeight = 13
  object Shape1: TShape
    Left = 65
    Top = 8
    Width = 720
    Height = 490
    Brush.Style = bsCross
  end
  object Shape8: TShape
    Left = 592
    Top = 416
    Width = 145
    Height = 115
    Shape = stCircle
  end
  object Shape9: TShape
    Left = 553
    Top = 408
    Width = 97
    Height = 115
    Brush.Color = clCream
    Shape = stCircle
  end
  object Shape10: TShape
    Left = 495
    Top = 448
    Width = 115
    Height = 83
    Brush.Color = clInactiveCaption
    Shape = stCircle
  end
  object Shape3: TShape
    Left = 112
    Top = 179
    Width = 217
    Height = 21
  end
  object Shape4: TShape
    Left = 112
    Top = 152
    Width = 217
    Height = 21
  end
  object Shape5: TShape
    Left = 112
    Top = 206
    Width = 217
    Height = 22
  end
  object Shape6: TShape
    Left = 112
    Top = 237
    Width = 217
    Height = 20
  end
  object Label1: TLabel
    Left = 165
    Top = 179
    Width = 107
    Height = 23
    Caption = 'Manufacturer'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label3: TLabel
    Left = 165
    Top = 206
    Width = 68
    Height = 23
    Caption = 'Quantity'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Label4: TLabel
    Left = 165
    Top = 235
    Width = 38
    Height = 23
    Caption = 'Price'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Shape12: TShape
    Left = 24
    Top = 32
    Width = 393
    Height = 49
    Brush.Color = clCream
  end
  object Label7: TLabel
    Left = 107
    Top = 46
    Width = 224
    Height = 27
    Caption = 'RETURNS OF STOCK'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -24
    Font.Name = 'Times New Roman'
    Font.Style = []
    ParentFont = False
  end
  object Shape7: TShape
    Left = 648
    Top = 355
    Width = 193
    Height = 168
    Brush.Color = clGradientInactiveCaption
    Shape = stCircle
  end
  object Label2: TLabel
    Left = 165
    Top = 148
    Width = 110
    Height = 23
    Caption = 'Product Name'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Shape13: TShape
    Left = 112
    Top = 267
    Width = 217
    Height = 20
  end
  object Label5: TLabel
    Left = 165
    Top = 263
    Width = 87
    Height = 23
    Caption = 'Expiry Date'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object Shape2: TShape
    Left = 112
    Top = 295
    Width = 217
    Height = 20
  end
  object Label6: TLabel
    Left = 165
    Top = 293
    Width = 85
    Height = 23
    Caption = 'Supplier ID'
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -19
    Font.Name = 'Calibri'
    Font.Style = []
    ParentFont = False
  end
  object btnBack: TButton
    Left = 709
    Top = 16
    Width = 60
    Height = 25
    Caption = 'BACK'
    TabOrder = 0
    OnClick = btnBackClick
  end
  object edtProductName: TEdit
    Left = 344
    Top = 152
    Width = 257
    Height = 21
    TabOrder = 1
    TextHint = 'Enter Product ID'
  end
  object edtManufacturer: TEdit
    Left = 344
    Top = 179
    Width = 257
    Height = 21
    TabOrder = 2
    TextHint = 'Enter the Manufacturer'
  end
  object edtPrice: TEdit
    Left = 344
    Top = 234
    Width = 257
    Height = 21
    TabOrder = 3
    TextHint = 'R1000.00'
  end
  object edtSupplierID: TEdit
    Left = 344
    Top = 293
    Width = 257
    Height = 21
    TabOrder = 4
    TextHint = 'Enter Supplier ID'
  end
  object spnQuanitiy: TSpinEdit
    Left = 344
    Top = 206
    Width = 257
    Height = 22
    MaxValue = 100
    MinValue = 0
    TabOrder = 5
    Value = 0
  end
  object dtpExpiryDate: TDateTimePicker
    Left = 344
    Top = 261
    Width = 257
    Height = 26
    Date = 45105.642920451390000000
    Time = 45105.642920451390000000
    TabOrder = 6
  end
  object btnRecord: TButton
    Left = 112
    Top = 416
    Width = 108
    Height = 25
    Caption = 'RECORD'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -16
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 7
    OnClick = btnRecordClick
  end
end
