program frmMenu_p;

uses
  Forms,
  frmMainPage_u in 'frmMainPage_u.pas' {frmMainPage},
  frmMenu_u in 'frmMenu_u.pas' {frmMenu},
  frmLogin_u in 'frmLogin_u.pas' {frmLogin};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmMainPage, frmMainPage);
  Application.CreateForm(TfrmMenu, frmMenu);
  Application.CreateForm(TfrmLogin, frmLogin);
  Application.Run;
end.
