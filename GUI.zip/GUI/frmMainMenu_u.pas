unit frmMainMenu_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, frmStock_u, frmUsers_u, frmFinances_u, pngimage;

type
  TfrmMainMenu = class(TForm)
    Shape1: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Shape11: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape2: TShape;
    Shape14: TShape;
    Shape16: TShape;
    Shape17: TShape;
    Shape18: TShape;
    Shape20: TShape;
    Shape15: TShape;
    Shape3: TShape;
    Shape4: TShape;
    btnStock: TButton;
    btnFinance: TButton;
    btnUser: TButton;
    btnLogOut: TButton;
    Image1: TImage;
    Image2: TImage;
    Image3: TImage;
    btnHelp: TButton;
    procedure btnStockClick(Sender: TObject);
    procedure btnUserClick(Sender: TObject);
    procedure btnFinanceClick(Sender: TObject);
    procedure btnLogOutClick(Sender: TObject);
    procedure btnHelpClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmMainMenu: TfrmMainMenu;

implementation
uses
  frmMenu_u, frmHelp_u;


{$R *.dfm}

procedure TfrmMainMenu.btnHelpClick(Sender: TObject);
begin
  frmHelp.show;
  frmMainMenu.Hide;
end;

procedure TfrmMainMenu.btnLogOutClick(Sender: TObject);
//link with Menu Screen
begin
  frmMainMenu.Hide;
  frmMenu.show;
end;

procedure TfrmMainMenu.btnFinanceClick(Sender: TObject);
//Finances button
begin
  frmMainMenu.hide;
  frmFinances.show;
end;

procedure TfrmMainMenu.btnStockClick(Sender: TObject);
//Stock button
begin
  frmMainMenu.hide;
  frmStock.show;
end;

procedure TfrmMainMenu.btnUserClick(Sender: TObject);
//User button
begin
  frmMainMenu.hide;
  frmUsers.show;
end;

end.
