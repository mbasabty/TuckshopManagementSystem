unit frmMenu_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, pngimage, ExtCtrls, frmLogin_u;

type
  TfrmMenu = class(TForm)
    Shape1: TShape;
    Shape3: TShape;
    Shape4: TShape;
    Shape5: TShape;
    Shape6: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Shape11: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape2: TShape;
    Shape12: TShape;
    Shape13: TShape;
    Shape14: TShape;
    ImgHHS: TImage;
    ImgQCS: TImage;
    ImgQCJ: TImage;
    Label1: TLabel;
    btnHelp: TButton;
    btnBack: TButton;
    procedure btnGHSClick(Sender: TObject);
    procedure btnQCSClick(Sender: TObject);
    procedure btnQCJClick(Sender: TObject);
    procedure ImgQCSMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure ImgHHSMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure ImgQCJMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure btnBackClick(Sender: TObject);
    procedure btnHelpClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmMenu: TfrmMenu;

implementation
uses
  frmMainMenu_u, frmMainPage_u,frmHelp_u;

{$R *.dfm}

procedure TfrmMenu.btnBackClick(Sender: TObject);
begin
  frmMainPage.show;
  frmMenu.Hide;

end;

procedure TfrmMenu.btnGHSClick(Sender: TObject);
//GHS button
begin
 frmMenu.Hide;
 frmLogin.show;
end;

procedure TfrmMenu.btnHelpClick(Sender: TObject);
begin
  frmHelp.show;
  frmMenu.Hide;
end;

procedure TfrmMenu.btnQCJClick(Sender: TObject);
//QCJ button
begin
  frmMenu.Hide;
  frmLogin.show;
end;

procedure TfrmMenu.btnQCSClick(Sender: TObject);
//QCS button
begin
  frmMenu.Hide;
  frmLogin.show;
end;

procedure TfrmMenu.ImgHHSMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  frmMenu.Hide;
  frmLogin.Show;
end;

procedure TfrmMenu.ImgQCSMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  frmMenu.Hide;
  frmLogin.Show;
end;

procedure TfrmMenu.ImgQCJMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  frmMenu.Hide;
  frmLogin.Show;
end;

end.
