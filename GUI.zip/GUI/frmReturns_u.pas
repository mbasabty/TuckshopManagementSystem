unit frmReturns_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, ComCtrls, Spin, StdCtrls, ExtCtrls, dmTTControl_u;

type
  TfrmReturns = class(TForm)
    Shape1: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    btnBack: TButton;
    Label2: TLabel;
    Shape3: TShape;
    Shape4: TShape;
    Shape5: TShape;
    Shape6: TShape;
    Label1: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    Label6: TLabel;
    edtProductName: TEdit;
    edtManufacturer: TEdit;
    edtPrice: TEdit;
    edtSupplierID: TEdit;
    spnQuanitiy: TSpinEdit;
    dtpExpiryDate: TDateTimePicker;
    btnRecord: TButton;
    Shape12: TShape;
    Label7: TLabel;
    Shape7: TShape;
    Shape13: TShape;
    Shape2: TShape;
    procedure btnBackClick(Sender: TObject);
    procedure btnRecordClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmReturns: TfrmReturns;

implementation
uses
  frmStock_u;

{$R *.dfm}

procedure TfrmReturns.btnBackClick(Sender: TObject);
//link with stock screen
begin
  frmReturns.Hide;
  frmStock.show;
end;

procedure TfrmReturns.btnRecordClick(Sender: TObject);
begin
 with dmTTControl do
  begin
    tblStockPurchased.Open;
    tblStockPurchased.sort := 'ProductID';  //primary key
    tblStockPurchased.last;

  ///enter a record to a database
    tblStockReturned.Insert;
    tblStockReturned['ProductName']   := edtProductName.Text;
    tblStockReturned['Manufacturer']  := edtManufacturer.text;
    tblStockReturned['SupplierID']    := edtSupplierID.Text;
    tblStockReturned['Quantity']      := spnQuanitiy.Value;
    tblStockReturned['Price']         := strtofloat(edtPrice.Text);
    tblStockReturned['ExpiryDate']    := dtpExpiryDate.date;

    showmessage('Successfully recorded');
  end;
end;

end.
