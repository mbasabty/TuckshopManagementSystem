object dmTTControl: TdmTTControl
  OldCreateOrder = False
  Height = 336
  Width = 493
  object conTTControl: TADOConnection
    Connected = True
    ConnectionString = 
      'Provider=Microsoft.Jet.OLEDB.4.0;User ID=Admin;Data Source=TTCon' +
      'trol.mdb;Mode=ReadWrite;Persist Security Info=False;Jet OLEDB:Sy' +
      'stem database="";Jet OLEDB:Registry Path="";Jet OLEDB:Database P' +
      'assword="";Jet OLEDB:Engine Type=5;Jet OLEDB:Database Locking Mo' +
      'de=1;Jet OLEDB:Global Partial Bulk Ops=2;Jet OLEDB:Global Bulk T' +
      'ransactions=1;Jet OLEDB:New Database Password="";Jet OLEDB:Creat' +
      'e System Database=False;Jet OLEDB:Encrypt Database=False;Jet OLE' +
      'DB:Don'#39't Copy Locale on Compact=False;Jet OLEDB:Compact Without ' +
      'Replica Repair=False;Jet OLEDB:SFP=False'
    LoginPrompt = False
    Mode = cmReadWrite
    Provider = 'Microsoft.Jet.OLEDB.4.0'
    Left = 216
    Top = 80
  end
  object tblUsers: TADOTable
    Active = True
    Connection = conTTControl
    CursorType = ctStatic
    TableDirect = True
    TableName = 'Users'
    Left = 88
    Top = 136
  end
  object dsrUsers: TDataSource
    DataSet = tblUsers
    Left = 96
    Top = 224
  end
  object tblStockPurchased: TADOTable
    Active = True
    Connection = conTTControl
    CursorType = ctStatic
    TableName = 'StockPurchased'
    Left = 168
    Top = 136
  end
  object dsrStockPurchased: TDataSource
    DataSet = tblStockPurchased
    Left = 168
    Top = 224
  end
  object tblStockReturned: TADOTable
    Active = True
    Connection = conTTControl
    CursorType = ctStatic
    TableName = 'Returns'
    Left = 248
    Top = 136
  end
  object dsrStockReturned: TDataSource
    DataSet = tblStockReturned
    Left = 264
    Top = 224
  end
  object tblFinances: TADOTable
    Active = True
    Connection = conTTControl
    CursorType = ctStatic
    TableName = 'Finances'
    Left = 344
    Top = 136
  end
  object dsrFinances: TDataSource
    DataSet = tblFinances
    Left = 344
    Top = 224
  end
end
