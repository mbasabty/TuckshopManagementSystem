unit frmSales_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls, dmTTControl_u, Grids, DBGrids;

type
  TfrmSales = class(TForm)
    Shape1: TShape;
    Shape12: TShape;
    Label7: TLabel;
    btnDisplay: TButton;
    btnBack: TButton;
    redout: TRichEdit;
    procedure btnBackClick(Sender: TObject);
    procedure btnDisplayClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmSales: TfrmSales;

implementation
uses
  frmFinances_u;

{$R *.dfm}

procedure TfrmSales.btnBackClick(Sender: TObject);
begin
  frmSales.Hide;
  frmFinances.show;
end;

procedure TfrmSales.btnDisplayClick(Sender: TObject);
var
  rPurchases, rSoldStock, rFinalAmount  : real;
  myfile : textfile;
  sLine : string;
  iPos : integer;

begin
  redout.Paragraph.TabCount := 2;
  redout.paragraph.tab[0] := 100;
  redout.paragraph.tab[1] := 200;
  redout.Lines.Add('Profit or Loss');
  redout.Lines.Add('-------------------------------------------------');
  redout.lines.Add('');
  ///reading from the textfile

  /// checking if file exists
if (fileexists ('SAVE.txt')<> true) then
  begin
    showmessage('File does not exist');
    Exit;
  end;


 AssignFile(myfile,'SAVE.txt');
 Reset(myfile);
/// reading begins
 while NOT eof (myfile) do
  begin
    Readln(myfile,sLine);
    iPos := pos('#',sline);
    rPurchases := strtofloat(copy(sLine,1,iPos-1));
    delete(sLine,1,iPos);
    rSoldStock := strtofloat((sLine));
    redout.Lines.Add('Purchases : '+floattostrF(rSoldStock,ffCurrency,8,2));
    redout.Lines.Add('Stock Sold : '+floattostrF(rPurchases,ffCurrency,8,2));
  end;
  Closefile(myfile);

  ////
  rFinalAmount := rPurchases - rSoldStock;
  redout.Lines.Add('-------------------------------------------------');
  redout.Lines.Add('Profit/Loss :'+floattostrF(rFinalAmount,ffCurrency,8,2));

 rPurchases := 0;
 rSoldStock := 0;
 rFinalAmount := 0;

 dmTTControl.tblFinances.First;
 with dmTTControl do
 begin
   while NOT(tblFinances.Eof) do
    begin
        rPurchases := rPurchases + tblFinances['Purhcases'];
        rSoldStock := rSoldStock + tblFinances['SoldStock'];
    end;
    tblFinances.Next;
 end;

 rFinalAmount := rPurchases-rSoldStock;
  if (rFinalAmount>rPurchases) then
    redout.Lines.Add('Profit : '+ floattostrF(rFinalAmount,ffCurrency,8,2))
 else
    if (rFinalAmount<rPurchases) then
      redout.Lines.Add('Loss : '+ floattostrF(rFinalAmount,ffCurrency,8,2))
end;

end.
