program frmStock_p;

uses
  Forms,
  frmMainPage_u in 'frmMainPage_u.pas' {frmMainPage},
  frmMenu_u in 'frmMenu_u.pas' {frmMenu},
  frmLogin_u in 'frmLogin_u.pas' {frmLogin},
  frmMainMenu_u in 'frmMainMenu_u.pas' {frmMainMenu},
  frmStock_u in 'frmStock_u.pas' {frmStock},
  frmUsers_u in 'frmUsers_u.pas' {frmUsers};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfrmMainPage, frmMainPage);
  Application.CreateForm(TfrmMenu, frmMenu);
  Application.CreateForm(TfrmLogin, frmLogin);
  Application.CreateForm(TfrmMainMenu, frmMainMenu);
  Application.CreateForm(TfrmStock, frmStock);
  Application.CreateForm(TfrmUsers, frmUsers);
  Application.Run;
end.
