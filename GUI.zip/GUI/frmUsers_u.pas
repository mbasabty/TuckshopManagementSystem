unit frmUsers_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, ComCtrls, dmTTControl_u, Grids, DBGrids, pngimage;

type
  TfrmUsers = class(TForm)
    Shape1: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Shape11: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape2: TShape;
    Shape12: TShape;
    Shape13: TShape;
    Shape14: TShape;
    Shape16: TShape;
    Shape17: TShape;
    Shape18: TShape;
    Shape20: TShape;
    Shape15: TShape;
    Shape5: TShape;
    Label1: TLabel;
    btnBack: TButton;
    Image1: TImage;
    Image3: TImage;
    DBGrid1: TDBGrid;
    btnSearch: TButton;
    btnDelete: TButton;
    btnReset: TButton;
    btnUpdate: TButton;
    edtSurname: TEdit;
    Shape3: TShape;
    lblUpdate: TLabel;
    edtPassword: TEdit;
    edtName: TEdit;
    rgpGeneder: TRadioGroup;
    edtUsername: TEdit;
    Image2: TImage;
    cmbSchool: TComboBox;
    procedure btnBackClick(Sender: TObject);
    procedure btnSearchClick(Sender: TObject);
    procedure btnDeleteClick(Sender: TObject);
    procedure btnResetClick(Sender: TObject);
    procedure btnUpdateClick(Sender: TObject);

  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmUsers: TfrmUsers;

implementation
uses
  frmMainMenu_u;

{$R *.dfm}

procedure TfrmUsers.btnBackClick(Sender: TObject);
//link with Main Menu screen
begin
  frmUsers.hide;
  frmMainMenu.show;
end;

procedure TfrmUsers.btnDeleteClick(Sender: TObject);
begin
with dmTTControl do
 begin
   if (MessageDLG('Are you sure you want to delete record for : '+
   tblUsers['NAME'] + ' ' + tblUsers['Surname'] + '?', mtWarning, [mbOk,mbCancel],0) = mrOk)  then
   tblUsers.Delete;
 end;
end;

procedure TfrmUsers.btnResetClick(Sender: TObject);
//Reseting a database
begin
  with dmTTControl do
  begin
    tblUsers.filtered := false;
  end;
end;

procedure TfrmUsers.btnSearchClick(Sender: TObject);
var
  sName :string;
begin
  with dmTTControl do
  begin
    sName := inputbox('NAME','Enter your name',' ');
    tblUsers.filtered := false;
    tblUsers.Filter := 'Name = '+ quotedstr(sName);
    tblUsers.Filtered := true;
  end;
end;

procedure TfrmUsers.btnUpdateClick(Sender: TObject);
begin
  with dmTTControl do
  begin
    tblUsers.Open;
    tblUsers.Sort := 'AdminNo';
    tblUsers.Last;
    tblUsers.Insert;
    ////
      tblUsers['Name'] := edtName.Text;
      tblUsers['Surname'] := edtSurname.Text;
      tblUsers['School'] := cmbSchool.Text;
      tblUsers['Password'] := edtPassword.text;
      tblUsers['Username'] := edtUsername.Text;
    ////
       case rgpGeneder.itemindex of
        0 : tblUsers['Gender'] := 'Male';
        1 : tblUsers['Gender'] := 'Female';
       end;
    ////
    tblUsers.Post;
    showmessage('your updates have been saved');
    end;
end;

end.
