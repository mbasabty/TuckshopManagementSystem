unit frmSignUp_u;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, pngimage, ExtCtrls, frmMainPage_u;

type
  TfrmSignUp = class(TForm)
    Shape1: TShape;
    Shape3: TShape;
    Shape4: TShape;
    Shape5: TShape;
    Shape6: TShape;
    Shape8: TShape;
    Shape9: TShape;
    Shape10: TShape;
    Shape11: TShape;
    Shape19: TShape;
    Shape7: TShape;
    Shape2: TShape;
    Shape12: TShape;
    Shape13: TShape;
    Shape14: TShape;
    Label1: TLabel;
    Image1: TImage;
    Image3: TImage;
    edtPassword: TEdit;
    btnLogin: TButton;
    btnExit: TButton;
    Label3: TLabel;
    Label4: TLabel;
    edtName: TEdit;
    edtSurname: TEdit;
    Label2: TLabel;
    cmbSchool: TComboBox;
    Shape15: TShape;
    Shape16: TShape;
    Shape17: TShape;
    Shape18: TShape;
    Shape20: TShape;
    rgpGeneder: TRadioGroup;
    Shape21: TShape;
    Shape22: TShape;
    Label5: TLabel;
    edtUsername: TEdit;
    Image2: TImage;
    procedure btnExitClick(Sender: TObject);
    procedure btnLoginClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmSignUp: TfrmSignUp;

implementation
uses
  dmTTControl_u;

{$R *.dfm}

procedure TfrmSignUp.btnExitClick(Sender: TObject);
begin
  frmSignUp.Hide;
  frmMainPage.show;
end;

procedure TfrmSignUp.btnLoginClick(Sender: TObject);
var
  sName, sSurname, sAdmin, sPassword : string;
  login : textfile;
begin
  sName := edtName.Text;
  sSurname := edtSurname.Text;
  sPassword := edtPassword.Text;

  //loading into a database
  with dmTTControl do
  begin
    tblUsers.Open;
    tblUsers.sort := 'AdminNo';  //primary key
    tblUsers.last;

    tblUsers.Insert;
    tblUsers['Username'] := edtUsername.text;
    tblUsers['Name']     := sName;
    tblUsers['Surname']  := sSurname;
    tblUsers['Password'] := sPassword;
    tblUsers['School']   := cmbSchool.Text;

     case rgpGeneder.itemindex of
      0 : tblUsers['Gender'] := 'Male';
      1 : tblUsers['Gender'] := 'Female';
     end;

    tblUsers.Post;

    showmessage('your login details have been successfully been saved');
  end;
end;
end.
