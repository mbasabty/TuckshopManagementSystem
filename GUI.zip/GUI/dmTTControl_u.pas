unit dmTTControl_u;

interface

uses
  SysUtils, Classes, DB, ADODB;

type
  TdmTTControl = class(TDataModule)
    conTTControl: TADOConnection;
    tblUsers: TADOTable;
    dsrUsers: TDataSource;
    tblStockPurchased: TADOTable;
    dsrStockPurchased: TDataSource;
    tblStockReturned: TADOTable;
    dsrStockReturned: TDataSource;
    tblFinances: TADOTable;
    dsrFinances: TDataSource;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  dmTTControl: TdmTTControl;

implementation

{$R *.dfm}

end.
